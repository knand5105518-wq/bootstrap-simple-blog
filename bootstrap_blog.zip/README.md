# Simple Blog Layout Using Bootstrap 5

## 📌 Objective
A responsive blog layout built using Bootstrap 5, featuring a navbar, blog post cards, and a footer.

## 🛠 Tools
- VS Code
- Bootstrap 5 (CDN)
- Browser

## 📂 Structure
- `index.html` → Main blog page

## 🚀 How to Run
1. Download the project files.
2. Open `index.html` in your browser.

## 🎯 Features
- Responsive Navbar
- Blog cards with images, titles, descriptions, and buttons
- Footer with social icons
- Fully responsive design using Bootstrap

## 📷 Preview
![Preview](https://via.placeholder.com/800x400)

## 📄 License
This project is open source for learning purposes.
